﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Data.SqlClient;
namespace SocketServer
{
    class Program
    {

        // Please change the drive from D: to where you have copied this project.
       static SqlConnection con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = D:\CurrentWare\SocketServer\DBSocket.mdf; Integrated Security = True");
  
       static SqlCommand com = new SqlCommand();
        static SqlDataReader reader=null;
        static void Main(string[] args)
        {
            con.Open();
            com.Connection = con;
            
            Socket server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            server.Bind(new IPEndPoint(0, 8080));
            server.Listen(0);
            Console.WriteLine("Server started.\n\tListening on port 8080");
            Socket recv = server.Accept();

            int counter = 0;
            byte[] dataRecv = new byte[recv.SendBufferSize];
            byte[] dataSend = new byte[255];
            int recvCount;
            string message = string.Empty;

            try
            {

                do
                {

                    recvCount = recv.Receive(dataRecv);
                    byte[] thedata = new byte[recvCount];
                    Array.Copy(dataRecv, thedata, recvCount);
                    string DataFromClient = Encoding.Default.GetString(thedata);
                    if (DataFromClient.Trim() == "increment")
                    {
                        counter++;
                        Update();
                        message = "Response from server\n\t(Success) Value incremented to: " + GetData();
                    }
                    else if (DataFromClient.Trim() == "evaluate")
                    {
                        message = "Response from server\n\tCurrent value is: " + GetData();
                    }


                    dataSend = Encoding.Default.GetBytes(message);
                    Console.WriteLine("Response sent to client \n\t{0}", Encoding.Default.GetString(dataSend));

                    recv.Send(dataSend, 0, dataSend.Length, 0);


                } while (dataRecv.Length > 0);


            }
            catch
            {
                Console.WriteLine("Connection Closed by client. Ending Application");
                Environment.Exit(-1);
                con.Close();
            }
            finally
            {
                server.Close();
                recv.Close();
                con.Close();
            }
        }

        static void Update()
        {
            try
            {
                com.CommandText = "update count set value = (select max(value) + 1 from count)";
                com.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
            
        }


    static string GetData()
    {
            string data=string.Empty;
        try
        {
            com.CommandText = "Select value from Count";
            reader = com.ExecuteReader();
           
                while (reader.Read())
                {
                   data += reader["value"].ToString();
                }
                reader.Close();
                return data;
        }
        catch (Exception ex)
        {

                return "from GetData() :" + ex.Message;
        }
        
        

    }

} 

    
}
