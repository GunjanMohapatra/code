﻿CREATE TABLE [dbo].[Count]
(
	[value] INT 
)
