﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
namespace Challenge
{
    class Program
    {
        /*
             On this part I need more clarification.
                Spawn 500 processes that, after 5 seconds of initialization, send an "increment" message followed by "evaluate" message
             */
        /*
          does it mean wait for 5 seconds and then send 500 messages or send 500 messages, each message after every 5 seconds.
         */

        /*
            Anyway the method SendMessages(500) will send 500 messages after 5 seconds
          */


        static void Main(string[] args)
        {
            Console.Write("Do you want to send one message at a time? (y/n) ");
            string res = Console.ReadLine();

            if (res.Trim().ToLower() == "y")
            {
                UserInput();
            }
            else
            {
                SendMessages(500);
            }

            
        }

        static void UserInput()
        {
            Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            client.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8080));
            Console.WriteLine("Enter + to increment the value, any other string to see the current value and enter quit to close client");
            Console.WriteLine("");
            string messageValue = "";
            byte[] dataSend = new byte[255];
            byte[] dataRecv = new byte[255];
            int recvCount;
                       
            while (true)
            {

                Console.Write("Enter value: ");
                messageValue = Console.ReadLine();
                if (messageValue.ToLower() == "quit")
                {
                    break;
                }
                else if (messageValue.Trim() == "+")
                {
                    messageValue = "increment";
                }
                else
                {
                    messageValue = "evaluate";
                }
                Array.Resize(ref dataSend, messageValue.Length);
                dataSend = Encoding.Default.GetBytes(messageValue);

                client.Send(dataSend, 0, dataSend.Length, 0);

                recvCount = client.Receive(dataRecv);
                byte[] thedata = new byte[recvCount];
                Array.Copy(dataRecv, thedata, recvCount);
                Console.WriteLine("{0}", Encoding.Default.GetString(thedata));

            }
            Console.WriteLine("connection closed");
            client.Close();
            Environment.Exit(-1);
        }

        static void SendMessages(int times)
        {
            

            Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            client.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8080));
            string messageValue = "";
            byte[] dataSend = new byte[255];
            byte[] dataRecv = new byte[255];
            int recvCount;
            Console.WriteLine("Connection to server established. Messages will be processed after 5 seconds.");
            System.Threading.Thread.Sleep(TimeSpan.FromSeconds(5));

            for (int count=0; count <times;)
            {
                
                messageValue = (messageValue == "+" || messageValue == "increment") ? "" : "+";
                
                if (messageValue.Trim() == "+")
                {
                    messageValue = "increment";
                    count++;
                }
                else
                {
                    messageValue = "evaluate";
                }
                Array.Resize(ref dataSend, messageValue.Length);
                dataSend = Encoding.Default.GetBytes(messageValue);

                client.Send(dataSend, 0, dataSend.Length, 0);

                recvCount = client.Receive(dataRecv);
                byte[] thedata = new byte[recvCount];
                Array.Copy(dataRecv, thedata, recvCount);
                Console.WriteLine("{0}", Encoding.Default.GetString(thedata));

            }
            Console.WriteLine("connection closed");
            client.Close();
            Environment.Exit(-1);
        }

        
    }
}
